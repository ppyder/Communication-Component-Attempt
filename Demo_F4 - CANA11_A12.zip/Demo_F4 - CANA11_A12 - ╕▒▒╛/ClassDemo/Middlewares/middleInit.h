#ifndef MIDDLEINIT_H
#define MIDDLEINIT_H

void COM_ModulesInit(void);

#endif
