#include "M3508.h"
#include "can.h"

short id = 0x200;

uint8_t   TxData[8]; 
uint8_t   RxData[8];

short Real_C_Value[3] = {0};        //�����ʵ����ֵ
short Real_V_Value[3] = {0};        //�����ʵ�ٶ�ֵ
long Real_A_Value[3] = {0};         //�����ʵ�Ƕ�ֵ

//�������͵���ֵ
void M3508SetCurrent(uint16_t id, int16_t Current1, int16_t Current2, int16_t Current3, int16_t Current4)
{
	CAN_TxHeaderTypeDef tx_message;
		
	tx_message.StdId = id;          //֡IDΪ���������CAN_ID
	tx_message.IDE = CAN_ID_STD;    //��׼֡
	tx_message.RTR = CAN_RTR_DATA;  //����֡
	tx_message.DLC = 0x08;          //֡����Ϊ8
	 
	TxData[0] = Current1 >> 8;
	TxData[1] = Current1;
	TxData[2] = Current2 >> 8;
	TxData[3] = Current2;
	TxData[4] = Current3 >> 8;
	TxData[5] = Current3;
	TxData[6] = Current4 >> 8;
	TxData[7] = Current4;

	if (HAL_CAN_AddTxMessage(&hcan1, &tx_message, TxData, (uint32_t *)CAN_TX_MAILBOX0) != HAL_OK)
	{
	      /* Transmission request Error */
          Error_Handler();
	}
}

/*******************************************************************************************
  * @Func	  void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef* _hcan)
  * @Brief    �������Ե����Ϣ�Ļص�����
  * @Param		
  * @Retval		None 
  * @Date     
 *******************************************************************************************/
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
	CAN_RxHeaderTypeDef rx_message;
	
	HAL_CAN_GetRxMessage( &hcan1, CAN_RX_FIFO0, &rx_message, RxData);

    if(rx_message.StdId == id + 0x01)          
    {    
		 Real_A_Value[0] = (RxData[0]<<8)|(RxData[1]);  //�Ƕ�ֵ
         Real_V_Value[0] = (RxData[2]<<8)|(RxData[3]);  //�ٶ�ֵ
         Real_C_Value[0] = (RxData[4]<<8)|(RxData[5]);  //����ֵ
    }
    if(rx_message.StdId == id + 0x02)          
    {    
		 Real_A_Value[1] = (RxData[0]<<8)|(RxData[1]);  //�Ƕ�ֵ
         Real_V_Value[1] = (RxData[2]<<8)|(RxData[3]);  //�ٶ�ֵ
         Real_C_Value[1] = (RxData[4]<<8)|(RxData[5]);  //����ֵ
    }
    if(rx_message.StdId == id + 0x03)          
    {    
		 Real_A_Value[2] = (RxData[0]<<8)|(RxData[1]);  //�Ƕ�ֵ
         Real_V_Value[2] = (RxData[2]<<8)|(RxData[3]);  //�ٶ�ֵ
         Real_C_Value[2] = (RxData[4]<<8)|(RxData[5]);  //����ֵ
    }
}
