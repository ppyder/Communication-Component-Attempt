#ifndef MASTERDATADEAL_H
#define MASTERDATADEAL_H

#include "ComToMaster.h"

//��ȡ�������ݹ�ʾ
extern SampleCMDTypedef SampleCMD;


extern enum MstrRxMsgTypes RxMsgTypeFeedBack;
extern enum Mstr_TxMsgTypes TxMsgTypeSaved;


bool GetTxData(union MstrTxUnionType *pUnion, uint8_t DataType);
bool GetMsgFromMstrBuffer(Mstr_RxBufTypedef *pBuffer);

#endif
