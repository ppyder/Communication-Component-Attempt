/**
 ******************************************************************************
 * @file    queue.c
 * @brief   �����ײ㣺������صĲ���.
 *              + Initialization and de-initialization functions
 *              + IO operation functions
 ******************************************************************************
 *
 * Copyright (C) HITwh Excellent Robot Organization(HERO). 2015-2018. All rights reserved.
 *
 * @version 1.0 ʾ���汾
 * @author  ���ෲ
 * @contact 17863107058(�ֻ�)   942041771(qq)
 * @date    2018/10/21
 *
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "queue.h"

/************************ (C) COPYRIGHT HITwh Excellent Robot Organization(HERO). *****END OF FILE****/
